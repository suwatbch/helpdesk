<?php
header('Content-Type: text/html; charset=tis-620');
header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=monthly_report.xls");

include_once '../../include/config.inc.php';
//include_once '../../include/template/index_report.tpl.php';
include_once '../../include/class/util/dateUtil.class.php';
include_once "../../include/error_message.php";

//comp=' + comp + '&start=' + d1 + '&end=' + d2 + '&c3=' + prd_tier_id3
//+ '&c3_l=' + prd_tier_id3_l + '&sta=' + status_id + '&sta_l=' + status_id_l 
//+ '&zone=' + customer_zone_id + '&zone_l=' + customer_zone_id_l
                            

$comp_id = $_GET["comp"];
$start_date = $_GET["start"];
$end_date = $_GET["end"];


$dp_start = dateUtil::thai_date($start_date);
$dp_end = dateUtil::thai_date($end_date);




$text_head_1 = "ระบบ Helpdesk";
$text_head_2 = "โครงการระบบคอมพิวเตอร์ซอฟต์แวร์สำหรับธุรกิจหลัก";
$text_reportname = "รายงานการให้บริการ SPIES Helpdesk ตามเขต กฟภ. ในช่วงเวลา $dp_start ถึง $dp_end";


include_once 'monthly_report.action.php';
if ($chk_dup_data != 0) {
    echo "<script type='text/javascript'>
    alert('มีรายการในช่วงเวลาที่คุณเลือกอยู่แล้ว กรุณาเลือกวันที่ให้ถูกต้อง')
    window.close();
    </script>";
}
if($criteria["arr_criteria"]){ $arr_criteria = $criteria["arr_criteria"]; }
if($criteria["total_row"]){ $total_row_criteria = $criteria["total_row"]; }

$pea = array();

$grandtotal_pea = array();
$grandtotal_total = 0;

//echo $_SERVER["PHP_SELF"];

//additional part
$report_id = "";
$response_id = "";
$final = "";
$report_type_id = 7; // monthly report
$additional_hd = array();
$additional_dt = array();

$additional_hd = getadditional_hd($comp_id,$start_date,$end_date,$report_type_id);
if ($additional_hd){
    foreach ($additional_hd["data"] as $value) {
        $report_id = $value["id"];
        $response_id = $value["response_id"];
        $final = $value["final"];
    }
    $additional_dt = getadditional_dt($report_id);
}

?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"

xmlns:x="urn:schemas-microsoft-com:office:excel"

xmlns="http://www.w3.org/TR/REC-html40">

<HTML>

<HEAD>

<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />

</HEAD>
    <body>
        <div name="Head">
            <table style="color: black; font-weight: bold; font-size: 20px; ">
                <tr><td colspan="<?=$total_row_criteria+3;?>"  style="width: 100%; border-bottom:  #cc0000 solid 5px; " align="center"><?=$text_reportname;?></td></tr>
            </table>
        </div><br>
        
            <table border="1px">
                <tr style=" background-color:#B9BCBD">
                    <th align="center" width="20%">Module</th>
                    <th align="center" width="10%">Quantity & Percentage</th>
                    
            <?
                if (count($arr_criteria) > 0){ 
                    $i = 0;
                    foreach ($arr_criteria as $list) {
                        $pea[$i] = $list["zone_id"];
                        $grandtotal_pea[$i] = 0;
                ?>
                    <th align="center" width="5%"><div class="rotate" ><?=$list["name"];?></div></th>
                <?
                    $i++;
                    }
                }
            ?>
                    <th align="center" width="5%"><span style="color: #cc0000;">Grand Total: #Ticket/%Ticket</span></th>
                </tr>
                
                <?
                    $incident_type = getincidenttype($comp_id);
                    foreach ($incident_type as $list) {
                        
                        $incident_type_id = $list["ident_type_id"];
                        $total_bytype = 0;
                        
                        ?>
                <tr style=" background-color:#B9BCBD">
                    <td colspan="2" style="background-color: #F3E2A9; font-weight: bold; color: #178AEB;" ><?=$list["ident_type_desc"];?></td>
                    <?
                            // count incident by type,zone
                            $count_byzone = array();
                        for ($index = 0; $index < count($pea); $index++) {
                            $zone_id = $pea[$index];
                            $count_byzone[$index] = countIncident_typezone($comp_id,$incident_type_id,$start_date,$end_date,$zone_id);
                            $total_bytype += $count_byzone[$index];
                            
                            
                            //Grand Total
                            $grandtotal_pea[$index] += $count_byzone[$index];
                            $grandtotal_total += $count_byzone[$index];
                            
                                
                    ?>
                    
                    <td style="background-color: #F3E2A9; font-weight: bold; color: #178AEB;"  align="right"><?= $count_byzone[$index];?></td>
                    
                    <?
                        }//end count incident type by zone
                    ?>
                    <td style="background-color: #F3E2A9; font-weight: bold; color: #178AEB;" align="right"><span style="color: #cc0000;"><?=$total_bytype;?></span></td>
                </tr>
                    <?
                        //get resolved product class3 master
                        $class3 = getclass3($comp_id);
                        if (count($class3) > 0){ 
                            foreach ($class3 as $list){
                                $class3_id = $list["prd_tier_id"];
                                $class3_name = $list["prd_tier_name"];
                                $count_class3 = array();
                                $total_count_class3 = 0;
                                
                                //loop to count incident class3 by zone
                                for ($index = 0; $index < count($pea); $index++) {
                                    $zone_id = $pea[$index];
                                    $count_class3[$index] = countIncident_typezoneclass3($comp_id,$incident_type_id,$class3_id,$start_date,$end_date,$zone_id);
                                    $total_count_class3 += $count_class3[$index];

                                }
                                
                                // if has data : write <tr>
                                if ($total_count_class3 != 0){
                                ?>
                <!--  ============ จำนวน Ticket ===================== --> 
                <tr>
                    <td align="left" style="background-color: #E6E0F8;"><?=$class3_name;?></td>
                    <td align="left" style="background-color: #E6E0F8;">จำนวน Ticket</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                    ?>
                    <td align="right" style="background-color: #E6E0F8;"><?=$count_class3[$index];?></td>
                                    <?
                                    
                                    }
                                    
                                    ?>
                    <td align="right" style="background-color: #E6E0F8;"><span style="color: #cc0000;"><?=$total_count_class3;?></span></td>
                </tr> <!-- end จำนวน Ticket -->  
                
                <!--  ============ % เทียบตาม Module ===================== --> 
                <tr>
                    <td align="left" >&nbsp;</td>
                    <td align="left" >% เทียบตาม Module</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                        $percentage = 0.0;
                                        if ($count_class3[$index] != 0){
                                           $percentage =  ($count_class3[$index]/$total_count_class3)*100;
                                        }
                                    ?>
                    <td align="right" ><?=round($percentage,2)."%"; ?></td>
                                    <?
                                    
                                    }
                                    
                                    $total_percentage = ($total_count_class3/$total_bytype)*100;
                                    ?>
                    <td rowspan="2" align="right" ><span style="color: #FF4000;"><?=  round($total_percentage,2). "%";?></span></td>
                </tr> <!-- end เทียบตาม Module -->  
                
                <!--  ============ % เทียบตามเขต กฟภ. ===================== --> 
                <tr>
                    <td align="left" >&nbsp;</td>
                    <td align="left">% เทียบตามเขต กฟภ.</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                        $percentage = 0.0;
                                        if ($count_class3[$index] != 0){
                                            if ($count_byzone[$index] == 0){
                                                $percentage = 0;
                                            }else {
                                                $percentage =  ($count_class3[$index]/$count_byzone[$index])*100;
                                            }
                                           
                                        }
                                    ?>
                    <td align="right" ><?=round($percentage,2)."%"; ?></td>
                                    <?
                                    
                                    }
                                    
//                                    $total_percentage = ($total_count_class3/$total_bytype)*100;
                                    ?>
                   </tr> <!-- end เทียบตาม Module -->  
                
                
                                        <?
                                }//end check has data to write
                            }//end loop master class3
                        }//end if master class3
                     
                    }// end loop incident_type master
                
                ?>
                   
                   <tr style=" background-color:#ebddc4; font-weight: bold; color: red;">
                       <td align="left" colspan="2" >Grand Total</td>
                       <?
                        foreach ($grandtotal_pea as $value) {
                            ?>
                        <td align="right"><?=$value;?></td>
                             <?
                        }
                    ?>
                     <td align="right"><?=$grandtotal_total;?></td>
                   </tr>
                
                
                
            </table>

        <br> <br>
        <input type="hidden" id="comp_id" name="comp_id" value="<?= $_GET["comp"];?>" />
        <input type="hidden" id="start_date" name="start_date" value="<?= $_GET["start"];?>" />
        <input type="hidden" id="end_date" name="end_date" value="<?= $_GET["end"];?>" />
        <input type="hidden" id="report_type_id" name="report_type_id" value="7" />
        
        <?
            if ($grandtotal_total != 0){
               ?>
                   
        <hr>
        <div width="60%">
            <?  
                $subject_add = "*จากสถิติจำนวนตามโมดูลงานที่ติดต่อผ่านเจ้าหน้าที่ SPIES  ช่วงเวลา $dp_start ถึง $dp_end";
//                $report_type_id = 7; //monthly report
                include_once '../common/additional_export.php';  
            ?>
        </div>   
                   
                   <? 
                
                
            }
        ?>

        
        
    </body>
</html>
