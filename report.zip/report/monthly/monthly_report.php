<?php
include_once '../../include/config.inc.php';
include_once '../../include/template/index_report.tpl.php';
include_once '../../include/class/util/dateUtil.class.php';
include_once "../../include/error_message.php";
                           

$comp_id = $_GET["comp"];
$start_date = $_GET["start"];
$end_date = $_GET["end"];


$dp_start = dateUtil::thai_date($start_date);
$dp_end = dateUtil::thai_date($end_date);




$text_head_1 = "ระบบ Helpdesk";
$text_head_2 = "โครงการระบบคอมพิวเตอร์ซอฟต์แวร์สำหรับธุรกิจหลัก";
$text_reportname = "รายงานการให้บริการ SPIES Helpdesk ตามเขต กฟภ. ในช่วงเวลา $dp_start ถึง $dp_end";


include_once 'monthly_report.action.php';
if ($chk_dup_data != 0) {
    echo "<script type='text/javascript'>
//    alert('มีรายการในช่วงเวลาที่คุณเลือกอยู่แล้ว กรุณาเลือกวันที่ให้ถูกต้อง')
    jAlert(\"error\", \"มีรายการในช่วงเวลาที่คุณเลือกอยู่แล้ว กรุณาเลือกวันที่ให้ถูกต้อง !\", \"Helpdesk System : Messages\")
    window.close();
    </script>";
}
if($criteria["arr_criteria"]){ $arr_criteria = $criteria["arr_criteria"]; }
if($criteria["total_row"]){ $total_row_criteria = $criteria["total_row"]; }

$pea = array();
$pea_name = array();

$grandtotal_pea = array();
$grandtotal_total = 0;

//echo $_SERVER["PHP_SELF"];

//additional part
$report_id = "0";
$response_id = "";
$final = "";
$report_type_id = 7; // monthly report
$additional_hd = array();
$additional_dt = array();

$additional_hd = getadditional_hd($comp_id,$start_date,$end_date,$report_type_id);
if ($additional_hd){
    foreach ($additional_hd["data"] as $value) {
        $report_id = $value["id"];
        $response_id = $value["response_id"];
        $final = $value["final"];
    }
    $additional_dt = getadditional_dt($report_id);
}
$total_percentage = 0;


# Data to push in additional 1 tb
$ad1_pea_area_pc = array();
$ad1_max_howto = array(
    "name" => "",
    "val" => 0
);
$ad1_more_percent = FALSE;



# Data to push in additional 2 tb
$ad2_pea_area_pc = array(
    "name"=> "",
    "val"=> 0
);
$ad2_max_inc = array();
$ad2_more_percent = FALSE;
$temp_percent  = array(
    "name"=> "",
    "val"=> 0
);
        

     
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset=utf-8 />
        <meta name="viewport" content="width=620" />
        <title>Incident Monthly Report</title>
        <link type="text/css" rel="stylesheet" href="../../include/css/report.css"/>
        <script type="text/javascript">
         $(document).ready(function () {    
             
            
            $("#send").click(function() {
//                alert('ddd');
                var employee_id = $("#employee_id").val();
                if (employee_id == "0" || employee_id == "") {
                    jAlert('warning', 'กรุณาเลือกพนักงานที่ต้องการก่อนการบันทึก!', 'Helpdesk System : Messages');
                    return false;
                };
                
                var head = new Array();
                var tb1 = gettable("tb_additional_1");
                var tb2 = gettable("tb_additional_2");
                var tb3 = gettable("tb_additional_3");
                
                head[0] = "save";
                head[1] = $("#report_type_id").val() ;
                head[2] = $("#comp_id").val();
                head[3] = $("#start_date").val();
                head[4] = $("#end_date").val();
                head[5] = $("#employee_id").val();
                head[6] = $("#report_id").val();
                head[7] = "N"; //approve report (no edit anymore)
 
                
            $.ajax({
                type: "POST",
                url: "../common/additional.action.php",
                data : {t1:tb1,t2:tb2,t3:tb3,header:head} ,         
                beforeSend:function(){
                    // this is where we append a loading image
                    $('#ajax-panel').html('<img src="../../images/loading_small.gif" alt="Loading..." />');
                },
                success: function(respone){
                    if (respone == ""){
                        $("#message").html('บันทึกรายการไม่สมบูรณ์!');
                    }else {
                        $("#report_id").val(respone);
                        $("#message").html("บันทึกรายการเรียบร้อยแล้ว");
                        
                        var emp = $("#employee_id").val();
                        var us = $("#user_id").val();
                        
                        if (emp != us){
                            $("span#employee").hide();
                            $("#send").hide();
                            $("#final").hide();
//                               $("#savearea").hide();
                        }
                        
                    }
                    $('#ajax-panel').empty();
                 
                },
                error:function(){
                 $("#message").html('บันทึกรายการไม่สมบูรณ์!');
                 $('#ajax-panel').empty();  
                }
            });
        });
        
        
        
        
        $("#final").click(function() {
//alert('final');
                var head = new Array();
                var tb1 = gettable("tb_additional_1");
                var tb2 = gettable("tb_additional_2");
                var tb3 = gettable("tb_additional_3");
                
                head[0] = "save";
                head[1] = $("#report_type_id").val() ;
                head[2] = $("#comp_id").val();
                head[3] = $("#start_date").val();
                head[4] = $("#end_date").val();
                head[5] = $("#response_id").val(); //approve report : response = own user_id
                head[6] = $("#report_id").val();
                head[7] = "Y"; //approve report (no edit anymore)
 
            $.ajax({
                type: "POST",
                url: "../common/additional.action.php",
                data : {t1:tb1,t2:tb2,t3:tb3,header:head} ,         
                beforeSend:function(){
                    // this is where we append a loading image
                    $('#ajax-panel').html('<img src="../../images/loading_small.gif" alt="Loading..." />');
                },
                success: function(respone){
                    if (respone == ""){
                        $("#message").html('บันทึกรายการไม่สมบูรณ์!');
                    }else {
                        $("#message").html("บันทึกรายการเรียบร้อยแล้ว");
                        
//                        $("#savearea").hide();
                        $("span#employee").hide();
                        $("#send").hide();
                        $("#final").hide();
                    }
                    $('#ajax-panel').empty();
                 
                },
                error:function(){
                 $("#message").html('บันทึกรายการไม่สมบูรณ์!');
                 $('#ajax-panel').empty();  
                }
            });
        });
        
        
        
        
        $("a[name=1_addRow]").click(function() {
            appendTR("tb_additional_1");
            return false;
 	});
        
        
        $("a[name=2_addRow]").click(function() {
            appendTR("tb_additional_2");
            return false;
 	});
        
        
        $("a[name=3_addRow]").click(function() {
            appendTR("tb_additional_3");
            return false;
 	});
        
        
        $("table.tb_additional a.nonborder").live("click", function() {
		$(this).parents("tr").remove();
				
	});
        
        $("#export_excel").click(function(){
//                alert('aa');
                var url = 'monthly_export.php' + '?comp=' + <?=$_GET["comp"];?> + '&start=' + <?=$_GET["start"];?> + '&end=' + <?=$_GET["end"];?> ;
                window.open(url, '',''); 
         });
        
       
        
});


 function gettable(name){
    var tb = new Array();
    var tb_name = "table#" + name + " tr";
    var n = 0;
    
    $(tb_name).each(function() {
        
            var $this = $(this);
            tb[n] = new Array();
            tb[n][0] = $this.find('#number').val();
            tb[n][1] = $this.find('#text1').val();
            tb[n][2] = $this.find('#text2').val();
            tb[n][3] = $this.find('#text3').val();
            tb[n][4] = $this.find('#text4').val();
            tb[n][5] = $this.find('#remark').val();
                    
            n = n+1;

           });
    return tb;
 }
 


    function appendTR(name){
        var tb_name = "table#" + name + " tr:last";//# + name + " tr";
        var str_append = "<tr>";
        str_append += "<td align='center'><a id='trash' name='trash' class='nonborder' ><img src='<?=$application_path_images;?>/trash.png' /></a></td>";
        str_append += "<td><input type='text' name='number' id='number' style='text-align: center;' value='' /></td>";
        str_append += "<td><input type='text' name='text1' id='text1' value='' /></td>";
        str_append += "<td><input type='text' name='text2' id='text2' style='text-align: center;' value='' /></td>";
        str_append += "<td><input type='text' name='text3' id='text3' value='' /></td>";
        str_append += "<td><input type='text' name='text4' id='text4' style='text-align: center;' value='' /></td>";
        str_append += "<td><input type='text' name='remark' id='remark' value='' /></td>";
        str_append += "</tr>";
//        $(tb_name).append(str_append);
        $(tb_name).after(str_append);
        return false;

    }



        
        </script>
    </head>
    <body>
        <?
             include_once '../common/export.php';
            include_once '../common/report_header.php';
        ?>
        <br>
        <div name="Data">
            <table id="tb_data">
                <tr height="200px">
                    <th align="center" width="20%">Module</th>
                    <th align="center" width="10%">Quantity & Percentage</th>
                    
            <?
                if (count($arr_criteria) > 0){ 
                    $i = 0;
                    foreach ($arr_criteria as $list) {
                        $pea[$i] = $list["zone_id"];
                        $pea_name[$i] = $list["name"]; 
                        $grandtotal_pea[$i] = 0;
                ?>
                    <th align="center" width="5%"><div class="rotate" ><?=$list["name"];?></div></th>
                <?
                    $i++;
                    }
                }
            ?>
                    <th align="center"><span class="rotate" style="color:#cc0000;">Grand Total: #Ticket/%Ticket</span></th>
                </tr>
                
                <?
                    $incident_type = getincidenttype($comp_id);
                    
                    foreach ($incident_type as $list) {
                        
                        $incident_type_id = $list["ident_type_id"];
                        $total_bytype = 0;
                        
                        ?>
                <tr>
                    <td colspan="2" id="datahead"><?=$list["ident_type_desc"];?></td>
                    <?
                            // count incident by type,zone
                            $count_byzone = array();
                        for ($index = 0; $index < count($pea); $index++) {
                            $zone_id = $pea[$index];
                            $count_byzone[$index] = countIncident_typezone($comp_id,$incident_type_id,$start_date,$end_date,$zone_id);
                            $total_bytype += $count_byzone[$index];
                            
                            
                            //Grand Total
                            $grandtotal_pea[$index] += $count_byzone[$index];
                            $grandtotal_total += $count_byzone[$index];
                            
                                
                    ?>
                    
                    <td id="datahead" align="right"><?= $count_byzone[$index];?></td>
                    
                    <?
                        }//end count incident type by zone
                    ?>
                    <td id="datahead" align="right"><span class="total"><?=$total_bytype;?></span></td>
                </tr>
                    <?
                        //get resolved product class3 master
                        $class3 = getclass3($comp_id);
                        if (count($class3) > 0){ 
                            
                            foreach ($class3 as $list){
                                #clear module percent temp
                                $temp_percent  = array(
                                    "name"=> "",
                                    "val"=> 0
                                );
                                
                                $class3_id = $list["prd_tier_id"];
                                $class3_name = $list["prd_tier_name"];
                                $count_class3 = array();
                                $total_count_class3 = 0;
                                
                                //loop to count incident class3 by zone
                                for ($index = 0; $index < count($pea); $index++) {
                                    $zone_id = $pea[$index];
                                    $count_class3[$index] = countIncident_typezoneclass3($comp_id,$incident_type_id,$class3_id,$start_date,$end_date,$zone_id);
                                    $total_count_class3 += $count_class3[$index];

                                }
                                
                                // if has data : write <tr>
                                if ($total_count_class3 != 0){
                                ?>
                <!--  ============ จำนวน Ticket ===================== --> 
                <tr>
                    <td align="left" id="datasub-count"><?=$class3_name;?></td>
                    <td align="left" id="datasub-count">จำนวน Ticket</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                    ?>
                    <td align="right" id="datasub-count"><?=$count_class3[$index];?></td>
                                    <?
                                    
                                    }
                                    
                                    ?>
                    <td align="right" id="datasub-count"><span class="total"><?=$total_count_class3;?></span></td>
                </tr> <!-- end จำนวน Ticket -->  
                
                <!--  ============ % เทียบตาม Module ===================== --> 
                <tr>
                    <td align="left" id="datasub">&nbsp;</td>
                    <td align="left" id="datasub">% เทียบตาม Module</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                        $percentage = 0.0;
                                        if ($count_class3[$index] != 0){
                                           $percentage =  ($count_class3[$index]/$total_count_class3)*100;
                                        }
                                        
                                        if (($percentage >= $temp_percent["val"]) && $incident_type_id == 2){
                                            $temp_percent  = array(
                                                "name"=> $pea_name[$index],
                                                "val"=> round($percentage,2)
                                            );
//                                            $temp_percent["val"] = round($percentage,2);
//                                            $temp_percent["name"] = $pea_name[$index];
                                                    
                                        }
                                    ?>
                    <td align="right" id="datasub"><?=round($percentage,2)."%"; ?></td>
                                    <?
                                    
                                    
                                    } 
                                    $total_percentage = round(($total_count_class3/$total_bytype)*100,2);
                                    
//                                    $total_percentage_temp = round(($total_count_class3/$total_bytype)*100,2) ;
                                    // fill to auto additional
                                    if ($incident_type_id == 1 && ($total_percentage >= $ad1_max_howto["val"])){// How to
                                            unset($ad1_pea_area_pc);
                                            $ad1_more_percent = TRUE;
                                            $ad1_max_howto = array(
                                                "name" => $class3_name,
                                                "val" => $total_percentage
                                            );
                                            
                                    } elseif ($incident_type_id == 2 && ($total_percentage >= $ad2_max_inc["val"])){//Incident
                                            $ad2_more_percent = TRUE;
                                            $ad2_max_inc = array(
                                                "name" => $class3_name,
                                                "val" => $total_percentage
                                            );
                                            
                                            $ad2_pea_area_pc["val"] = $temp_percent["val"];
                                            $ad2_pea_area_pc["name"] = $temp_percent["name"];
                                            
                                    }else {
                                    
                                            $ad1_more_percent = FALSE;
                                            $ad2_more_percent = FALSE;
                                    }
                                    
                                    
                                    
                                    ?>
                    <td rowspan="2" align="right" id="datasub"><span class="totalpercent"><?= $total_percentage. "%";?></span></td>
                </tr> <!-- end เทียบตาม Module -->  
                
                <!--  ============ % เทียบตามเขต กฟภ. ===================== --> 
                <tr>
                    <td align="left" id="datasub">&nbsp;</td>
                    <td align="left" id="datasub">% เทียบตามเขต กฟภ.</td>
                                <?  // write count zone
                                    for ($index = 0; $index < count($count_class3); $index++) {
                                        $percentage = 0.0;
                                        if ($count_class3[$index] != 0){
                                            if ($count_byzone[$index] == 0){
                                                $percentage = 0;
                                            }else {
                                                $percentage =  ($count_class3[$index]/$count_byzone[$index])*100;
                                            }
                                            
                                            // fill to auto additional
                                            if ($incident_type_id == 1 && $ad1_more_percent == TRUE && $percentage != 0){// How to
                                                
                                                $ad1_pea_area_pc[$index]["name"] = $pea_name[$index];
                                                $ad1_pea_area_pc[$index]["val"] = round($percentage,2);
                                            }
                                            
//                                            if ($incident_type_id == 2 && $ad2_more_percent == TRUE && $percentage != 0 && $ad2_pea_area_pc["val"] <= $percentage){// How to
//                                                $ad2_pea_area_pc["val"] = round($percentage,2);
//                                                $ad2_pea_area_pc["name"] = $pea_name[$index];
//                                            }
                                           
                                        }
                                    ?>
                    <td align="right" id="datasub"><?=round($percentage,2)."%"; ?></td>
                                    <?
                                        
                                    }
                                    
//                                    $total_percentage = ($total_count_class3/$total_bytype)*100;
                                    ?>
                   </tr> <!-- end เทียบตามเขต กฟภ. -->  
                
                
                                        <?
                                }//end check has data to write
                            }//end loop master class3
                        }//end if master class3
                     
                    }// end loop incident_type master
                
                ?>
                   
                   <tr>
                       <td align="left" class="totalAll" colspan="2" >Grand Total</td>
                       <?
                        foreach ($grandtotal_pea as $value) {
                            ?>
                        <td class="totalAll" align="right"><?=$value;?></td>
                             <?
                        }
                    ?>
                     <td class="totalAll" align="right"><?=$grandtotal_total;?></td>
                   </tr>
                
                
                
            </table>
        </div>
        <br> <br>
        <input type="hidden" id="comp_id" name="comp_id" value="<?= $_GET["comp"];?>" />
        <input type="hidden" id="start_date" name="start_date" value="<?= $_GET["start"];?>" />
        <input type="hidden" id="end_date" name="end_date" value="<?= $_GET["end"];?>" />
        <input type="hidden" id="report_type_id" name="report_type_id" value="7" />
        
        <?
            if ($grandtotal_total != 0){
               ?>
                   
        <hr>
        <div width="60%">
            <?  
                $subject_add = "*จากสถิติจำนวนตามโมดูลงานที่ติดต่อผ่านเจ้าหน้าที่ SPIES  ช่วงเวลา $dp_start ถึง $dp_end";
         
                include_once '../common/additional.php';  
            ?>
        </div>   
                   
                   <? 
                
                
            }
        ?>
        
        
    <!--<link type="text/css" rel="stylesheet" href="../../include/css/cctstyles.css"/>-->    
<!--    <div id="dialog-customer" title="Customer">
        <iframe id="ifr_cus_id" frameborder="0" scrolling="no" width="100%" height="100%" src="" style="background-color: white; alignment-adjust: central;"></iframe>
    </div>       -->
        
        
    </body>
</html>
<style>
   @media {
    @page {
      size: B4 landscape;
      margin: 5px 5px 5px 5px;
      padding: 5px 5px 5px 5px;
    }
  }

</style>
