<?php
include_once "../../include/config.inc.php";
//    include_once 'aging_search.action.php';
$report = 1;
?>

<link type="text/css" rel="stylesheet" href="<?=$application_path_include?>/css/cctstyles.css"/> 
<div width="100%">
    <table id="tb_adv_left" width="90%">
        <tr>
            <td width="100%" align="left" margin="5px"><span class="styleGray">รายงานสรุปประเภท Helpdesk ตามเขตการไฟฟ้า</span><br><br>
                <input id="result_page" name="result_page" type="hidden" value="monthly_report.php" />
            </td>
        </tr>
        </table><br>
    
    <?
//    $report = 2;
    include '../common/criteria_search.php';
    ?>
<!--        <tr>
            <td></td>
            <th align="left">Company Code/รหัสบริษัท</th>
            <td align="left"><input type="text" /></td>
            <td align="center">To</td>
            <td><input type="text" /></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <th align="left">Incident Type/ประเภทงาน</th>
            <td align="left"><input type="text" /></td>
            <td align="center">To</td>
            <td><input type="text" /></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <th align="left">Incident Type/ประเภทงาน</th>
            <td align="left"><input type="text" /></td>
            <td align="center">To</td>
            <td><input type="text" /></td>
            <td></td>
        </tr>
        <tr>
            <td width="10%"></td>
            <td width="30%"></td>
            <td width="15%"></td>
            <td width="10%"></td>
            <td width="15%"></td>
            <td width="20%"></td>
        </tr>-->
    
    
</div>
