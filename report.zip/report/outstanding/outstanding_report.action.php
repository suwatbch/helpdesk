<?php
    include_once "../../include/error_message.php";
    include_once "../../include/function.php";
    include_once "../../include/class/user_session.class.php";
    include_once "../../include/class/util/strUtil.class.php";
    include_once "../../include/class/util/dateUtil.class.php";
    include_once "../../include/class/db/db.php";
    include_once "../../include/class/model/report.class.php";
    include_once "../../include/handler/action_handler.php";

    function unspecified() {
        global $report ,$db;
        $report = new report($db);
//        
//        $type = "report_aging";
//        getcriteria($type);
        
//        getClassdata($_GET["comp"]);
        
    }
    
    function getClassdata($comp_id,$class3_fr, $class3_to){
        global $report ,$db;
        
//        $report = new report($db);
//        $page = strUtil::nvl($_REQUEST["page"], "1");

        return  $report->out_getProdClassCurrent($comp_id,$class3_fr, $class3_to);
        
   }
   
   function balanceforward($comp_id,$date,$class1,$class2,$class3,$zone_fr,$zone_to){
        global $report ,$db;
        
//        $report = new report($db);
        return  $report->out_balanceforward($comp_id,$date,$class1,$class2,$class3,$zone_fr,$zone_to);
   }
   
   function open($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to){
       global $report ,$db;
        
//        $report = new report($db);
//        $page = strUtil::nvl($_REQUEST["page"], "1");

        return  $report->out_open($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to);
       
   }
   
   function closed_complete($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to){
       global $report ,$db;
       
      return  $report-> out_closed_complete($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to);
   }
   
   
   function closed_cancel($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to){
       global $report ,$db;
       
      return  $report-> out_closed_cancel($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to);
   }
   
   function closed_nocontact($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to){
       global $report ,$db;
       
      return  $report-> out_closed_nocontact($comp_id,$sdate,$class1,$class2,$class3,$zone_fr,$zone_to);
   }
   
   
   function outstanding_bystatus($comp_id,$date,$class1,$class2,$class3,$status,$zone_fr,$zone_to){
       global $report ,$db;
       
      return  $report-> out_outst_status($comp_id,$date,$class1,$class2,$class3,$status,$zone_fr,$zone_to);
   }
   
   
?>
