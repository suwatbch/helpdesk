<?php
    include_once '../../include/config.inc.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<link type="text/css" rel="stylesheet" href="../../include/css/report.css"/>
<div name="Head">
            <table id="tb_PEA">
                <tr>
                    <th align="center">
                        <img src="<?=$application_path_images?>/pea.png" class="nonborder" />
                    </th>
                    <td align="left">
                        <span id="big"><?=$text_head_1;?></span><br>
                        <span id="small"><?=$text_head_2;?></span>
                    </td>
                </tr>
                
            </table><br>
            <table id="tb_ReportName">
                <tr><td align="center"><?=$text_reportname;?></td></tr>
            </table>
</div>
