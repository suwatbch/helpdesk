<?php
//include_once "../../include/template/index_report.tpl.php";
include_once '../../include/config.inc.php';
include_once "../../include/class/user_session.class.php";
//include_once 'additional.action.php';


?>
<!--<link type="text/css" rel="stylesheet" href="../../include/css/report.css"/>
<script type="text/javascript" src="../../dialog/dialog.ui.js"></script>
<script type="text/javascript">
 $(document).ready(function () {	
 
});
        
function dialog_onSelected(lookuptype, obj){
        if (obj != null){
            if (lookuptype == "employee"){
                $("#employee_id").val(obj.employee_id);                
                $("#employee_name").val(obj.employee_name);

            }
          } 
}
 
 

 
 
</script>-->

<!--<label id="message" name="message"></label><br><br>
<input type="hidden" id="mode" name="mode" />
<input type="hidden" id="report_id" name="report_id" value="<?=$report_id;?>" />-->


<br><br>

<div name="additional">
    <span><b><? echo $subject_add;?></b></span><br><br><br>
    <div  style="width: 90%; background-color: #ffc4c4; font-weight: bold;">ด้านพัฒนาบุคคลากร</div><br>
    <table border="1px" width="90%">
        <tr  style="border: gray solid thin; background-color: #C3C7D3; color: #444444;">
            <th width="5%">ลำดับ</th>
            <th width="25%">ระบบงานที่ควรพัฒนาบุคคลากร</th>
            <th width="10%">% สถิติการแจ้ง SPIES ทั้งหมด</th>
            <th width="22%">เขตการไฟฟ้าที่ควรเข้ารับการพัฒนาบุคคลากร</th>
            <th width="10%">% สถิติการแจ้ง SPIES เทียบกับเขตอื่นๆ</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
        <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "1"){
                     ?>
        <tr>
            <td><?=$value["number"];?></td>
            <td><?=$value["text1"];?></td>
            <td><?=$value["text2"];?></td>
            <td><?=$value["text3"];?></td>
            <td><?=$value["text4"];?></td>
            <td><?=$value["remark"];?></td>
        </tr>     
                    <?   
                    }
                }
            }else{
                // no data or new
                ?>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>     
               <?
            }
        ?>
        
    </table>
    <br>
    <br>
    
    <div style="width: 90%; background-color: #ffc4c4; font-weight: bold;">ด้านการปรับปรุง ป้องกันระบบงาน IT และกระบวนการปฎิบัติงาน</div><br>
    
    <table border="1px"  width="90%">
         <tr  style="border: gray solid thin; background-color: #C3C7D3; color: #444444;">
            <th width="5%">ลำดับ</th>
            <th width="25%">ระบบงาน IT ที่ควรปรับปรุง ป้องกัน</th>
            <th width="10%">% สถิติการแจ้ง SPIES ทั้งหมด</th>
            <th width="22%">เขตการไฟฟ้าที่ควรปรับปรุงกระบวนการปฏิบัตงาน</th>
            <th width="10%">% สถิติการแจ้ง SPIES  เทียบกับเขตอื่นๆ</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
         <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "2"){
                     ?>
       <tr>
            <td><?=$value["number"];?></td>
            <td><?=$value["text1"];?></td>
            <td><?=$value["text2"];?></td>
            <td><?=$value["text3"];?></td>
            <td><?=$value["text4"];?></td>
            <td><?=$value["remark"];?></td>
        </tr>     
                    <?   
                    }
                }
            }else{
                // no data or new
                ?>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>     
               <?
            }
        ?>
        
    </table>
    
    
    <br>
    <br>
    
    <div style="width: 90%; background-color: #ffc4c4; font-weight: bold;">ประเด็นติดตามจากเดือนก่อนหน้า</div><br>
    
    <table border="1px"  width="90%">
         <tr  style="border: gray solid thin; background-color: #C3C7D3; color: #444444;">
            <th width="5%">ลำดับ</th>
            <th width="25%">ประเด็นที่ติดตาม</th>
            <th width="10%">เขตการไฟฟ้า</th>
            <th width="22%">แนวทางการแก้ไข</th>
            <th width="10%">ผลการปรับปรุง</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
         <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "3"){
                     ?>
        <tr>
            <td><?=$value["number"];?></td>
            <td><?=$value["text1"];?></td>
            <td><?=$value["text2"];?></td>
            <td><?=$value["text3"];?></td>
            <td><?=$value["text4"];?></td>
            <td><?=$value["remark"];?></td>
        </tr>      
                    <?   
                    }
                }
            }else{
                // no data or new
                ?>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>      
               <?
            }
        ?>
    </table>
    
    <br><br>
    
</div>
<!--</form>-->