<?php
include_once '../../include/config.inc.php';
include_once "../../include/class/user_session.class.php";


?>
<link type="text/css" rel="stylesheet" href="../../include/css/report.css"/>
<script type="text/javascript" src="../../dialog/dialog.ui.js"></script>

<script type="text/javascript">
 $(document).ready(function () {	
  
});
        
function dialog_onSelected(lookuptype, obj){
        if (obj != null){
            if (lookuptype == "employee"){
                $("#employee_id").val(obj.employee_id);                
                $("#employee_name").val(obj.employee_name);
                

            }
          } 
}
 
 

 
 
</script>
<br><br>
<label id="message" name="message"></label>
<input type="hidden" id="mode" name="mode" />
<input type="hidden" id="report_id" name="report_id" value="<?=$report_id;?>" />
<input type="hidden" id="response_id" name="response_id" value="<?=$response_id;?>" />
<input type="hidden" id="user_id" name="user_id" value="<?=user_session::get_user_id();?>" />



<table width="60%" cellpadding="0" cellspacing="5" id="savearea" name="savearea">
    
             <?
                if (user_session::get_edit_rpt_per() == 'Y' && user_session::get_user_id() == $response_id && $final != 'Y'){
                    ?>
    <tr>
        <td align="left" style="width: 350px;">
            <span lookuptype="employee" name="employee" id="employee" style="width: 300px;" title="Employee"  
                  dialogWidth="627" dialogHeight="400" param="edtreport=Y" />

        </td>
         <td align="left" style="width: 80px;">
            <div align="center" id="send" name="send" >Send</div>&nbsp;&nbsp;&nbsp;
         </td>
                     <?   
                        
                }elseif ($chk_dup_data == 0 && $report_id == 0 && user_session::get_edit_rpt_per() == 'Y' ){
                    ?>
                        <tr>
        <td align="left" style="width: 350px;">
            <span lookuptype="employee" name="employee" id="employee" style="width: 300px;" title="Employee"  
                  dialogWidth="627" dialogHeight="400" allowNone="true" />

        </td>
         <td align="left" style="width: 80px;">
            <div align="center" id="send" name="send" >Send</div>&nbsp;&nbsp;&nbsp;
        </td>
                     <? 
                }
                        
                        
                        
             
             ?>
        
        <td align="left" style="width: 120px;">
            <?
                if (user_session::get_appv_rpt_per() == 'Y' && user_session::get_user_id() == $response_id && $final != 'Y'){
                    ?>
                        <div align="center" id="final" name="final" value="Y" >Approve Report</div>
                        
                        <?
                }elseif ($chk_dup_data == 0 && $report_id == 0 && user_session::get_appv_rpt_per() == 'Y' ){
                    ?>
                        <div align="center" id="final" name="final" value="Y" >Approve Report</div>
                     <? 
                }
             
             ?>
            
            
        </td>
        <td align="left" style="width: 300px;">
            <div id="ajax-panel" name="ajax-panel"></div>
            
        </td>
     </tr>
</table>
<br><br>


<div name="additional">
    <span><b><? echo $subject_add;?></b></span><br><br><br>
    <div class="comment_subject" style="width: 90%">ด้านพัฒนาบุคคลากร</div><br>
    <table id="tb_additional_1" class="tb_additional" width="90%">
        <tr>
            <th width="3%"><a href="#" name="1_addRow"><img src="<?=$application_path_images;?>/plus.png" /></a></th>
            <th width="5%">ลำดับ</th>
            <th width="25%">ระบบงานที่ควรพัฒนาบุคคลากร</th>
            <th width="10%">% สถิติการแจ้ง SPIES ทั้งหมด</th>
            <th width="22%">เขตการไฟฟ้าที่ควรเข้ารับการพัฒนาบุคคลากร</th>
            <th width="10%">% สถิติการแจ้ง SPIES เทียบกับเขตอื่นๆ</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
        <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "1"){
                     ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" value="<?=$value["number"];?>" /></td>
            <td><input type="text" name="text1" id="text1" value="<?=$value["text1"];?>" /></td>
            <td><input type="text" name="text2" id="text2" style="text-align: center;"  value="<?=$value["text2"];?>" /></td>
            <td><input type="text" name="text3" id="text3" value="<?=$value["text3"];?>" /></td>
            <td><input type="text" name="text4" id="text4" style="text-align: center;"  value="<?=$value["text4"];?>" /></td>
            <td><input type="text" name="remark" id="remark" value="<?=$value["remark"];?>" /></td>
        </tr>     
                    <?   
                    }
                }
                
            }elseif ($chk_dup_data == 0 && $report_id == 0 && user_session::get_edit_rpt_per() == 'Y' ){

                $name = array();
                $val = array();
                foreach ($ad1_pea_area_pc as $key => $row) {
                    $val[$key] = $row['val'];
                }

                array_multisort($val, SORT_DESC, $ad1_pea_area_pc);

                $dt = count($ad1_pea_area_pc) - 1;
                for ($index=0; $index <= $dt; $index++){
                    if($index == 0){
                        $number = "1";
                        $text1 = $ad1_max_howto["name"];
                        $text2 = $ad1_max_howto["val"]."%";
                    }else{
                        $number = "";
                        $text1 = "";
                        $text2 = "";
                    }
                ?>
            <tr>
                <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
                <td><input type="text" name="number" id="number" style="text-align: center;" value="<?=$number;?>"/></td>
                <td><input type="text" name="text1" id="text1" value="<?=$text1;?>" /></td>
                <td><input type="text" name="text2" id="text2" style="text-align: center;" value="<?=$text2;?>"  /></td>
                <td><input type="text" name="text3" id="text3" value="<?=$ad1_pea_area_pc[$index]["name"];?>" /></td>
                <td><input type="text" name="text4" id="text4" style="text-align: center;" value="<?=$ad1_pea_area_pc[$index]["val"];?>%"  /></td>
                <td><input type="text" name="remark" id="remark" /></td>
            </tr>     
               <? 
               }
            }else{
                // no data or new
                ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" /></td>
            <td><input type="text" name="text1" id="text1" /></td>
            <td><input type="text" name="text2" id="text2" style="text-align: center;"  /></td>
            <td><input type="text" name="text3" id="text3" /></td>
            <td><input type="text" name="text4" id="text4" style="text-align: center;"  /></td>
            <td><input type="text" name="remark" id="remark" /></td>
        </tr>     
               <?
            }
        ?>
        
    </table>
    <br>
    <br>
    
    <div class="comment_subject" style="width: 90%">ด้านการปรับปรุง ป้องกันระบบงาน IT และกระบวนการปฎิบัติงาน</div><br>
    
    <table id="tb_additional_2" class="tb_additional"  width="90%">
        <tr>
            <th width="3%"><a href="#" name="2_addRow"><img src="<?=$application_path_images;?>/plus.png" /></a></th>
            <th width="5%">ลำดับ</th>
            <th width="25%">ระบบงาน IT ที่ควรปรับปรุง ป้องกัน</th>
            <th width="10%">% สถิติการแจ้ง SPIES ทั้งหมด</th>
            <th width="22%">เขตการไฟฟ้าที่ควรปรับปรุงกระบวนการปฏิบัตงาน</th>
            <th width="10%">% สถิติการแจ้ง SPIES  เทียบกับเขตอื่นๆ</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
         <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "2"){
                     ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" value="<?=$value["number"];?>" /></td>
            <td><input type="text" name="text1" id="text1" value="<?=$value["text1"];?>" /></td>
            <td><input type="text" name="text2" id="text2" style="text-align: center;"  value="<?=$value["text2"];?>" /></td>
            <td><input type="text" name="text3" id="text3" value="<?=$value["text3"];?>" /></td>
            <td><input type="text" name="text4" id="text4" style="text-align: center;"  value="<?=$value["text4"];?>" /></td>
            <td><input type="text" name="remark" id="remark" value="<?=$value["remark"];?>" /></td>
        </tr>     
                    <?   
                    }
                }
            }elseif ($chk_dup_data == 0 && $report_id == 0 && user_session::get_edit_rpt_per() == 'Y' ){
                               
                ?>
            <tr>
                <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
                <td><input type="text" name="number" id="number" style="text-align: center;" value="1"/></td>
                <td><input type="text" name="text1" id="text1" value="<?=$ad2_max_inc["name"];?>" /></td>
                <td><input type="text" name="text2" id="text2" style="text-align: center;" value="<?=$ad2_max_inc["val"];?>%"  /></td>
                <td><input type="text" name="text3" id="text3" value="<?=$ad2_pea_area_pc["name"];?>" /></td>
                <td><input type="text" name="text4" id="text4" style="text-align: center;" value="<?=$ad2_pea_area_pc["val"];?>%"  /></td>
                <td><input type="text" name="remark" id="remark" /></td>
            </tr>     
               <? 
               
            }else{
                // no data or new
                ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" /></td>
            <td><input type="text" name="text1" id="text1" /></td>
            <td><input type="text" name="text2" id="text2" style="text-align: center;"  /></td>
            <td><input type="text" name="text3" id="text3" /></td>
            <td><input type="text" name="text4" id="text4" style="text-align: center;"  /></td>
            <td><input type="text" name="remark" id="remark" /></td>
        </tr>     
               <?
            }
        ?>
        
    </table>
    
    
    <br>
    <br>
    
    <div class="comment_subject" style="width: 90%">ประเด็นติดตามจากเดือนก่อนหน้า</div><br>
    
    <table id="tb_additional_3" class="tb_additional"  width="90%">
        <tr>
            <th width="3%"><a href="#" name="3_addRow"><img src="<?=$application_path_images;?>/plus.png" /></a></th>
            <th width="5%">ลำดับ</th>
            <th width="25%">ประเด็นที่ติดตาม</th>
            <th width="10%">เขตการไฟฟ้า</th>
            <th width="22%">แนวทางการแก้ไข</th>
            <th width="10%">ผลการปรับปรุง</th>
            <th width="25%">ข้อเสนอแนะ</th>
        </tr>
         <?
            if ($additional_dt["total_row"] != 0){
                $detail = $additional_dt["data"];
                foreach ($detail as $value) {
                    if ($value["table_item"] == "3"){
                     ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" value="<?=$value["number"];?>" /></td>
            <td><input type="text" name="text1" id="text1" value="<?=$value["text1"];?>" /></td>
            <td><input type="text" name="text2" id="text2" style="text-align: center;" value="<?=$value["text2"];?>" /></td>
            <td><input type="text" name="text3" id="text3" value="<?=$value["text3"];?>" /></td>
            <td><input type="text" name="text4" id="text4" style="text-align: center;" value="<?=$value["text4"];?>" /></td>
            <td><input type="text" name="remark" id="remark" value="<?=$value["remark"];?>" /></td>
        </tr>     
                    <?   
                    }
                }
            }else{
                // no data or new
                ?>
        <tr>
            <td align="center"><a id="trash" name="trash" class="nonborder"><img src="<?=$application_path_images;?>/trash.png" /></a></td>
            <td><input type="text" name="number" id="number" style="text-align: center;" /></td>
            <td><input type="text" name="text1" id="text1" /></td>
            <td><input type="text" name="text2" style="text-align: center;" id="text2"  /></td>
            <td><input type="text" name="text3" id="text3" /></td>
            <td><input type="text" name="text4" style="text-align: center;" id="text4"  /></td>
            <td><input type="text" name="remark" id="remark" /></td>
        </tr>     
               <?
            }
        ?>
    </table>
    
    <br><br>
    
</div>


<!--</form>-->