<?php
    include_once "../../include/error_message.php";
    include_once "../../include/function.php";
    include_once "../../include/class/user_session.class.php";
    include_once "../../include/class/util/strUtil.class.php";
    include_once "../../include/class/util/dateUtil.class.php";
    include_once "../../include/class/db/db.php";
    include_once "../../include/class/model/report.class.php";
    include_once "../../include/handler/action_handler.php";

    function unspecified() {
        global $report ,$db;
        $report = new report($db);
        
        $type = "report_aging";
        getcriteria($type);
        
    }

    function finalize(){
//        global $db;
//        $db->close();
    }
    
    function getcriteria($type){
        global $report ,$criteria,$db;
        
        $report = new report($db);
        $page = strUtil::nvl($_REQUEST["page"], "1");

        $criteria =  $report->getCriteria($type, $page);
        
   }
   
   function countincident($company, $start_date, $inc_type, $class1, $class2, $class3,$min,$max ){
       global $db, $report;
       
       if ($max  == 0){ $max = ""; }
       
       $filter = array(
            "company_id" => $company
            ,"start_date" => $start_date
            , "inc_type_id" => $inc_type
           , "class1_id" => $class1
           , "class2_id" => $class2
           , "class3_id" => $class3
           , "value_min" => $min
           , "value_max" => $max 
           );
       
       return $report->aging_countIncident_byage($filter);
   }
   
   function getclass_data($company_id,$start,$class3_fr, $class3_to ){
       global $db,$report;
       
//       $report = new report($db);
       return $report->aging_getProdClassCurrent($company_id,$start,$class3_fr, $class3_to );
       
   }
?>
